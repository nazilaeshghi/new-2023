# NMA-2022
NMA 2022, Tempora pod, Group2 project

Up-to-date information on the project code
